package com.example.finalmsptask4.adapter

import com.example.finalmsptask4.data.User

interface Onclicked {
    fun OnClicked(user: User)
/*
    fun onItemClick(position:Int)
*/


}